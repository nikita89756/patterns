package user

type User struct{
	Name string
}